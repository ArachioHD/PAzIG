import { Component } from "@angular/core";

@Component({
  selector: "gr-app",
  template: "<page-router-outlet></page-router-outlet>"
})
export class AppComponent { }